
package examne.sebastian.aragon.mondol;

import java.util.Random;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class FrnHilosSebastian_Aragon_Mondol extends javax.swing.JFrame implements Runnable{
     private JButton boton;
     private boolean btnStopFactorial = true; 
     private boolean btnStopNumeros = true;
     private Thread thr1;
     private Thread thr2;
  
    
    public FrnHilosSebastian_Aragon_Mondol() {
        initComponents();
        setLocationRelativeTo(null);
      
    }
    
    private void NumAleatorios(){
    
      Random n = new Random();
      int vec [];
      Integer x = 0;
      Integer y = 0;
      Integer z = 0;
      Integer c = 0;
      Integer v = 0;
      Integer b = 0;
      
      for(int i=1; i<=100 && !btnStopNumeros; i++){
          x= (n.nextInt(50));
          y=(n.nextInt(50));
          z=(n.nextInt(50));
          c=(n.nextInt(50));
          v=(n.nextInt(50));
          b=(n.nextInt(50));
          btnNumero1.setText(x.toString());
          btnNumero2.setText(y.toString());
          btnNumero3.setText(z.toString());
          btnNumero4.setText(c.toString());
          btnNumero5.setText(v.toString());
          btnNumero6.setText(b.toString());
          try {          
                Thread.sleep(600);
            } catch (InterruptedException ex) {     
                JOptionPane.showMessageDialog(null,"Error" + ex);
            } 
      }
    }
    
     private void factorial() {
        Integer facto = 1;

        for (Integer i = 1; i <= 40 && !btnStopFactorial; i++) { // TAMBIEN PUEDE SER CUALQUIER OTRO NUMERO
           
            try {
                facto = facto * i;
                txtArea.append(facto.toString() + "\n\n");
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.out.println("Error" + ex);

            }
        }

    } 
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelBackgroundTitle1 = new org.edisoncor.gui.label.LabelBackgroundTitle();
        panelImage1 = new org.edisoncor.gui.panel.PanelImage();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        btnFactorial = new org.edisoncor.gui.button.ButtonAction();
        btnNumero2 = new org.edisoncor.gui.button.ButtonAqua();
        btnNumero3 = new org.edisoncor.gui.button.ButtonAqua();
        btnNumero5 = new org.edisoncor.gui.button.ButtonAqua();
        btnNumero1 = new org.edisoncor.gui.button.ButtonAqua();
        btnNumero6 = new org.edisoncor.gui.button.ButtonAqua();
        btnPlay = new org.edisoncor.gui.button.ButtonAction();
        btnNumero4 = new org.edisoncor.gui.button.ButtonAqua();
        btnStop = new org.edisoncor.gui.button.ButtonAction();
        btnStopFacto = new org.edisoncor.gui.button.ButtonAction();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelImage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/Fondo azul claro.jpg"))); // NOI18N

        txtArea.setColumns(20);
        txtArea.setRows(5);
        txtArea.setText("Arrastrar para ver Completo");
        jScrollPane1.setViewportView(txtArea);

        btnFactorial.setBackground(new java.awt.Color(102, 0, 0));
        btnFactorial.setForeground(new java.awt.Color(102, 0, 0));
        btnFactorial.setText("Factorial");
        btnFactorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFactorialActionPerformed(evt);
            }
        });

        btnNumero2.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero2.setText("0");

        btnNumero3.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero3.setText("0");

        btnNumero5.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero5.setText("0");

        btnNumero1.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero1.setText("0");

        btnNumero6.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero6.setText("0");

        btnPlay.setBackground(new java.awt.Color(102, 0, 0));
        btnPlay.setForeground(new java.awt.Color(102, 0, 0));
        btnPlay.setText("Inicio");
        btnPlay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPlayActionPerformed(evt);
            }
        });

        btnNumero4.setBackground(new java.awt.Color(102, 0, 51));
        btnNumero4.setText("0");

        btnStop.setForeground(new java.awt.Color(102, 0, 0));
        btnStop.setText("Parar");
        btnStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopActionPerformed(evt);
            }
        });

        btnStopFacto.setForeground(new java.awt.Color(102, 0, 0));
        btnStopFacto.setText("Parar");
        btnStopFacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopFactoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Bienvenido");

        javax.swing.GroupLayout panelImage1Layout = new javax.swing.GroupLayout(panelImage1);
        panelImage1.setLayout(panelImage1Layout);
        panelImage1Layout.setHorizontalGroup(
            panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelImage1Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btnNumero3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnNumero4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(btnNumero5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(btnNumero6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(btnNumero2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnNumero1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelImage1Layout.createSequentialGroup()
                        .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnStopFacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFactorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(65, 65, 65))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelImage1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(panelImage1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(btnPlay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnStop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelImage1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(157, 157, 157))
        );
        panelImage1Layout.setVerticalGroup(
            panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelImage1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelImage1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnFactorial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnStopFacto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelImage1Layout.createSequentialGroup()
                        .addComponent(btnNumero6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnNumero5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNumero3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addComponent(btnNumero4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnNumero2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnNumero1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(panelImage1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPlay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnStop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panelImage1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panelImage1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPlayActionPerformed
       boton = btnPlay;
       btnStopNumeros = false;
       btnNumero1.setText("");
       btnNumero2.setText("");
       btnNumero3.setText("");
       btnNumero4.setText("");
       btnNumero5.setText("");
       btnNumero6.setText("");   
       thr2 = new Thread(this,"Hilo1");
       thr2.start();
    }//GEN-LAST:event_btnPlayActionPerformed

    private void btnFactorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFactorialActionPerformed
       boton = btnFactorial;
       txtArea.setText("");
       btnStopFactorial=false;
       thr2 = new Thread(this,"Hilo2");
       thr2.start();
    }//GEN-LAST:event_btnFactorialActionPerformed

    private void btnStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopActionPerformed
       btnStopNumeros = true;
    }//GEN-LAST:event_btnStopActionPerformed

    private void btnStopFactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopFactoActionPerformed
      btnStopFactorial = true;
    }//GEN-LAST:event_btnStopFactoActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrnHilosSebastian_Aragon_Mondol.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrnHilosSebastian_Aragon_Mondol.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrnHilosSebastian_Aragon_Mondol.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrnHilosSebastian_Aragon_Mondol.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrnHilosSebastian_Aragon_Mondol().setVisible(true);
            }
        });
    }
    
     @Override
    public void run() {
        
        if(boton == btnPlay){
            NumAleatorios();    
        }else if(boton ==btnFactorial){
            factorial();
        }        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private org.edisoncor.gui.button.ButtonAction btnFactorial;
    private org.edisoncor.gui.button.ButtonAqua btnNumero1;
    private org.edisoncor.gui.button.ButtonAqua btnNumero2;
    private org.edisoncor.gui.button.ButtonAqua btnNumero3;
    private org.edisoncor.gui.button.ButtonAqua btnNumero4;
    private org.edisoncor.gui.button.ButtonAqua btnNumero5;
    private org.edisoncor.gui.button.ButtonAqua btnNumero6;
    private org.edisoncor.gui.button.ButtonAction btnPlay;
    private org.edisoncor.gui.button.ButtonAction btnStop;
    private org.edisoncor.gui.button.ButtonAction btnStopFacto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private org.edisoncor.gui.label.LabelBackgroundTitle labelBackgroundTitle1;
    private org.edisoncor.gui.panel.PanelImage panelImage1;
    private javax.swing.JTextArea txtArea;
    // End of variables declaration//GEN-END:variables

   
}

