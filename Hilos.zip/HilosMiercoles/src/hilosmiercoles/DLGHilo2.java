/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilosmiercoles;

/**
 *
 * @author HP
 */
public class DLGHilo2 extends javax.swing.JDialog implements Runnable {
private Thread thr;
    /**
     * Creates new form Dlghilo2
     */
    public DLGHilo2() {
        initComponents();
        setVisible(true);
        setLocation(300,100);
         thr = new Thread(this,"Hilo2");
        thr.start();
    }
    private void factorial(){
    Integer facto=1;
    
    for(Integer i=2; i<=20; i++){
    facto= facto*i;
    try{
    txtfactorial.append(facto.toString()+"\n");
    Thread.sleep(100);
    }
    catch(InterruptedException ex){
        System.out.println("Error"+ex);
    
    }
    }
    
    }

       @Override
    public void run() {
        factorial();
       
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtfactorial = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtfactorial.setColumns(20);
        txtfactorial.setRows(5);
        jScrollPane1.setViewportView(txtfactorial);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtfactorial;
    // End of variables declaration//GEN-END:variables
}
