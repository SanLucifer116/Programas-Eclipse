/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilosmiercoles;

public class Principal {
    public static void main(String[] args) {
        System.out.println("Hilo Principal Iniciado");
        DLGHilo1 dlghilo1= new DLGHilo1();
        DLGHilo2 dlghilo2= new DLGHilo2();
        System.out.println("Hilo Principal Finalizado");
    }
}
