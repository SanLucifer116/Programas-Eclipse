/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hilosmiercoles;

/**
 *
 * @author HP
 */
public class DLGHilo1 extends javax.swing.JDialog implements Runnable {

    private Thread thr;
    
    
    public DLGHilo1() {
        initComponents();
        setVisible(true);
        setLocation(10,100);
        thr = new Thread (this, "Hilo1");
        thr.start();
    }
    
   private void numeros() {
        for (Integer i = 1; i <= 100; i++) {
            txtArea.append(i.toString() + "\n");
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.out.println("error " + ex);

            }
        }

    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNumeros = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();

        javax.swing.GroupLayout txtNumerosLayout = new javax.swing.GroupLayout(txtNumeros);
        txtNumeros.setLayout(txtNumerosLayout);
        txtNumerosLayout.setHorizontalGroup(
            txtNumerosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 222, Short.MAX_VALUE)
        );
        txtNumerosLayout.setVerticalGroup(
            txtNumerosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 386, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JPanel txtNumeros;
    // End of variables declaration//GEN-END:variables

    @Override
    public void run() {
        numeros();
    }
}
